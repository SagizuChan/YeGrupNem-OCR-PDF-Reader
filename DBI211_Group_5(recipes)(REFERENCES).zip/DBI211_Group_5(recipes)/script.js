// Homepage javascript
document.getElementById("loginLink").addEventListener("click", function(e) {
    var isLoggedIn = localStorage.getItem("isLoggedIn");
    var hasPrompted = sessionStorage.getItem("hasPromptedForLogout");

    if (isLoggedIn === "true" && !hasPrompted) {
        // If the user is logged in and hasn't been prompted yet, show the prompt
        var userResponse = confirm("You are already logged in. Do you want to log out?");
        
        if (userResponse) {
            // If the user wants to log out, log them out
            logout();
        } else {
            // If the user does not want to log out, set a flag that we prompted them
            sessionStorage.setItem("isFirstLogin", "true");
        }
        
        // Prevent the default action of going to the login page if they clicked "No" in the prompt
        e.preventDefault();
    }
});

window.onload = function() {
    var isLoggedIn = localStorage.getItem("isLoggedIn");
    var hasPrompted = sessionStorage.getItem("hasPromptedForLogout");
    var isFirstLogin = sessionStorage.getItem("isFirstLogin");

    if (isLoggedIn === "true" && !hasPrompted && !isFirstLogin) {
        // Ask the user if they want to log out or go back to the homepage
        var userResponse = confirm("You are already logged in. Do you want to log out?");
        
        if (userResponse) {
            // If the user chooses to log out, log them out and redirect to the login page
            logout();
        } else {
            // Set "isFirstLogin" to false because the user is not logging out
            sessionStorage.setItem("isFirstLogin", "false");  // Set the value to false
            
            // Redirect to the homepage
            window.location = "index.html";
        }
        
        // Set a flag in sessionStorage to avoid showing the prompt again after reload
        sessionStorage.setItem("hasPromptedForLogout", "true");
    }

    // Clear the first login flag after the prompt has been handled
    if (isFirstLogin) {
        sessionStorage.removeItem("isFirstLogin");
    }
};

var page1Visible = true; // Initially, page1 is visible

// Function to show the previous page (page1) when needed
function previousPage() {
    if (page1Visible) {
        return; // If page1 is already visible, do nothing
    }
    // Show page1, hide page2
    document.querySelector('.page1').style.display = 'flex'; // Show page1
    document.querySelector('.page2').style.display = 'none'; // Hide page2
    page1Visible = true; // Update the current page state
}

// Function to toggle between page1 and page2, and loop back from page2 to page1
function nextPage() {
    // Toggle the page visibility between page1 and page2
    if (page1Visible) {
        // If page1 is visible, hide it and show page2
        document.querySelector('.page1').style.display = 'none';
        document.querySelector('.page2').style.display = 'flex'; // Show page2
        page1Visible = false; // Update the page state to indicate page2 is visible
    } else {
        // If page2 is visible, hide it and show page1
        document.querySelector('.page1').style.display = 'flex'; // Show page1
        document.querySelector('.page2').style.display = 'none'; // Hide page2
        page1Visible = true; // Update the page state to indicate page1 is visible
    }
}
function lol() {
    alert('I dont have a facebook account')
}

// Login javascripts
function clearFunc() {
    document.getElementById("email").value="";
    document.getElementById("msg1").innerHTML="";
    document.getElementById("pwd").value="";
    document.getElementById("msg2").innerHTML="";
    }

function Googlefill() {
    var emailField = document.getElementById("email");
    var emailValue = emailField.value.trim();  

    if (emailValue === "" || emailValue.endsWith("@hotmail.com") || emailValue.endsWith("@yahoo.com") || emailValue.endsWith("@outlook.com")) {
        emailField.value = "" + "@gmail.com"
    } else {
        if (!emailValue.includes("@gmail.com")) {
            emailField.value = emailValue + "@gmail.com";
        }
    }
}

function Yahoofill() {
    var emailField = document.getElementById("email");
    var emailValue = emailField.value;  

    if (emailValue === "" || emailValue.endsWith("@hotmail.com") || emailValue.endsWith("@gmail.com") || emailValue.endsWith("@outlook.com")) {
        emailField.value = "" + "@yahoo.com"; 
    } else {
        if (!emailValue.includes("@yahoo.com")) {
            emailField.value = emailValue + "@yahoo.com";
        }
    }
}

function Outlookfill() {
    var emailField = document.getElementById("email");
    var emailValue = emailField.value;  

    if (emailValue === "" || emailValue.endsWith("@hotmail.com") || emailValue.endsWith("@gmail.com") || emailValue.endsWith("@yahoo.com")) {
        emailField.value = "" + "@outlook.com"; 
    } else {
        if (!emailValue.includes("@outlook.com")) {
            emailField.value = emailValue + "@outlook.com";
        }
    }
}

function Hotmailfill() {
    var emailField = document.getElementById("email");
    var emailValue = emailField.value;  

    if (emailValue === "" || emailValue.endsWith("@outlook.com") || emailValue.endsWith("@gmail.com") || emailValue.endsWith("@yahoo.com")) {
        emailField.value = "" + "@hotmail.com"; 
    } else {
        if (!emailValue.includes("@hotmail.com")) {
            emailField.value = emailValue + "@hotmail.com";
        }
    }
}

//
function login() {
    var uname = document.getElementById("email").value;
    var pwd = document.getElementById("pwd").value;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})$/;

    if (uname == '') {
        document.getElementById("msg1").innerHTML = "Email field cannot be empty";
    } else if (pwd == '') {
        document.getElementById("msg2").innerHTML = "Please enter your password";
    } else if (!filter.test(uname)) {
        document.getElementById("msg1").innerHTML = "Please enter a valid email address.";
    } else if (pwd.length < 7) {
        document.getElementById("msg2").innerHTML = "Minimum password length is 7.";
    } else {
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("userEmail", uname);
        sessionStorage.removeItem("hasPromptedForLogout"); // Reset logout prompt flag

        // Set the first login flag to prevent prompt on page load
        sessionStorage.setItem("isFirstLogin", "true");

        alert('Successful login, redirecting to homepage');
        window.location = "index.html"; // Redirect to homepage after login
    }
}
function cancel() {
    window.location = "index.html"; 
    sessionStorage.setItem("isFirstLogin", "true");
}

function logout() {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("userEmail");
    sessionStorage.removeItem("hasPromptedForLogout"); // Clear session data when logging out
    sessionStorage.removeItem("isFirstLogin"); // Remove the first login flag

    alert("You have been logged out.");
    window.location = "login.html"; // Redirect to login page after logout
}

function checkLoginStatus() {
    var isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        alert("You must be logged in to provide feedback.");
        window.location = "login.html"; // Redirect to login page if not logged in
    }
}

// Use this function when trying to access feedback page
document.getElementById('feedbackLink').addEventListener('click', function(e) {
    e.preventDefault(); // Prevent default link behavior (navigating to feedback.html)

    var isLoggedIn = localStorage.getItem("isLoggedIn");

    if (isLoggedIn !== "true") {
        var userResponse = confirm("You need to login to give feedback. Would you like to login now?");
        if (userResponse) {
            window.location = "login.html"; // Redirect to login page
        } else {
            window.location = "index.html"; // Redirect back to homepage if the user declines login
        }
    } else {
        window.location = "feedback.html"; // Allow them to proceed to the feedback page
    }
});

// Feedback javascript

function feedback() {
    var isLoggedIn = localStorage.getItem("isLoggedIn");

    // Check if user is logged in
    if (isLoggedIn !== "true") {
        alert("You must be logged in to submit feedback.");
        window.location = "login.html"; // Redirect to login page if not logged in
        return; // Prevent form submission if not logged in
    }

    // Capture the feedback data
    var userName = document.getElementById("name").value;
    var userFeedback = document.getElementById("feedback").value;

    // Validation (if fields are empty)
    if (userName === "" || userFeedback === "") {
        alert("Please fill out both the name and feedback fields.");
        return; // Prevent form submission if fields are empty
    }

    // Prepare the content for the text file
    var content = "Name: " + userName + "\n\nFeedback:\n" + userFeedback;

    // Create a Blob object with the feedback content
    var blob = new Blob([content], { type: "text/plain" });

    // Create an object URL for the Blob
    var url = URL.createObjectURL(blob);

    // Create an anchor tag to trigger the download
    var link = document.createElement("a");
    link.href = url;
    link.download = "feedback.txt"; // Name of the file to download

    // Append the link to the body (it won't be visible)
    document.body.appendChild(link);

    // Trigger the click event on the link to start the download
    link.click();

    // Clean up by removing the link element
    document.body.removeChild(link);

    // Optionally, reset the form or alert the user
    alert("Thank you for your feedback! Your response has been saved.");
    document.getElementById("name").value = "";
    document.getElementById("feedback").value = "";
}

